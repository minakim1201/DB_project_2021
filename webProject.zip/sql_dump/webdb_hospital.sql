-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: webdb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hospital` (
  `hos_num` int NOT NULL,
  `hos_name` varchar(30) NOT NULL,
  `hos_address` varchar(30) NOT NULL,
  `hos_pnum` varchar(64) DEFAULT NULL,
  `hos_adnum` int NOT NULL,
  PRIMARY KEY (`hos_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospital`
--

LOCK TABLES `hospital` WRITE;
/*!40000 ALTER TABLE `hospital` DISABLE KEYS */;
INSERT INTO `hospital` VALUES (1,'미르내과의원','서울시 강남구 대치동 345','02-5675-2345',1),(2,' 태릉마이병원','서울시 강남구 역삼동 234','02-2345-5678',1),(3,' 하동욱내과의원','서울시 강남구 일원동 123','02-1234-3456',1),(4,'이다원내과의원','서울시 강동구 화양동 456','02-3333-2222',2),(5,' 김민아내과의원','서울시 강동구 자양동 89','02-5455-2315',2),(6,' 진달래의원','서울시 강동구 능동 78','02-5666-8845',2),(7,'무궁화의원','서울시 노원구 중계동 12','02-7565-7745',3),(8,'가나다라내과의원','서울시 노원구 하계동 89','02-1235-5555',3),(9,'에이비의원','서울시 노원구 상계동 99','02-1241-2345',3),(10,'강북연세병원','서울시 성북구 성북동 76-1','02-5675-2345',4),(11,'맑은병원','서울시 성북구 길음동 44','02-2233-5544',4),(12,'위대한병원','서울시 성북구 종암동 98','02-5675-2345',4),(13,'밝은내과의원','서울시 중랑구 신내동 87','02-3434-7777',5),(14,'제일내과의원','서울시 중랑구 망우동 99','02-1212-5656',5),(15,'더조은병원','서울시 중랑구 면목동 98','02-8888-2222',5);
/*!40000 ALTER TABLE `hospital` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-10 19:40:46
